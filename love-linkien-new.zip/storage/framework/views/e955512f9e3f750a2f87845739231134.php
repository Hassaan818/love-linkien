

<?php $__env->startSection('content'); ?>
<div class="contents">

    <div class="demo2 mb-25 t-thead-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">

                    <div class="breadcrumb-main">
                        <h4 class="text-capitalize breadcrumb-title">Meetings</h4>
                    </div>

                </div>

                <div class="col-lg-12">
                    <div class="card card-default card-md mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6>All Meetings</h6>
                            <!-- Optional Add button -->

                        </div>

                        <div class="card-body">
                            <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                            <?php endif; ?>

                            <div class="table-responsive">
                                <table class="table mb-0 table-borderless">
                                    <thead>
                                        <tr class="userDatatable-header">
                                            <th><span class="userDatatable-title">#</span></th>
                                            <th><span class="userDatatable-title">With</span></th>
                                            <th><span class="userDatatable-title">User</span></th>
                                            <th><span class="userDatatable-title">Meeting Date</span></th>
                                            <th><span class="userDatatable-title">Start Time</span></th>
                                            <th><span class="userDatatable-title">End Time</span></th>
                                            <th><span class="userDatatable-title">Email</span></th>
                                            <th><span class="userDatatable-title float-end">Actions</span></th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($meeting->adminUser->name ?? '—'); ?></td>
                                            <td><?php echo e($meeting->user->name ?? '—'); ?></td>
                                            <td><?php echo e($meeting->meeting_date); ?></td>
                                            <td><?php echo e($meeting->start_time); ?></td>
                                            <td><?php echo e($meeting->end_time); ?></td>
                                            <td><?php echo e($meeting->email); ?></td>

                                            <td class="text-end">
                                                <div class="d-inline-flex gap-2">

                                                <a href="<?php echo e(route('admin.meetings.show', [$meeting->id])); ?>" class="btn btn-sm btn-primary">Show</a>
                                                    <form method="POST" action="<?php echo e(route('admin.meetings.destroy', $meeting->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger"
                                                            onclick="return confirm('Are you sure you want to delete this meeting?')">
                                                            Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="11" class="text-center text-muted py-3">No meetings found</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="mt-3">
                                <?php echo e($meetings->links()); ?>

                            </div>
                        </div>
                    </div>
                    <!-- ends: card -->
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\love-linkien\resources\views/admin/meetings/index.blade.php ENDPATH**/ ?>