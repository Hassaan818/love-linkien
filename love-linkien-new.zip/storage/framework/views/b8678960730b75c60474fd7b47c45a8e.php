

<?php $__env->startSection('content'); ?>
<div class="contents">

    <div class="demo2 mb-25 t-thead-bg">
        <div class="container-fluid">
            <div class="row">
                <?php echo $__env->make('admin.partials.success-messages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('admin.partials.validation-error-messages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="col-lg-12">
                    <div class="breadcrumb-main">
                        <h4 class="text-capitalize breadcrumb-title">Edit Availability</h4>
                    </div>
                </div>

                <div class="col-lg-12">
                    <div class="card card-default card-md mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6>Edit Availability</h6>
                            <a href="<?php echo e(route('admin.availability.index')); ?>" class="btn btn-light btn-default btn-squared">
                                Back to List
                            </a>
                        </div>

                        <div class="card-body py-md-30">
                            <form method="POST" action="<?php echo e(route('admin.availability.update', $availability->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <label>Select Admin User</label>
                                        <select name="user_id" class="form-control">
                                            <option value="">-- Select Admin --</option>

                                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($admin->id); ?>"
                                                <?php echo e($availability->user_id == $admin->id ? 'selected' : ''); ?>>
                                                <?php echo e($admin->name); ?> (<?php echo e($admin->email); ?>)
                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>


                                <div class="border rounded p-3 mb-3">
                                    <div class="row">

                                        <div class="col-md-4 mb-25">
                                            <label>Select Date</label>
                                            <input type="date" name="date" value="<?php echo e($availability->date); ?>" class="form-control"
                                                min="<?php echo e(date('Y-m-d')); ?>">
                                        </div>

                                        <div class="col-md-8 mb-25">
                                            <label>Time Slots</label>

                                            <div class="slot-container">
                                                <?php $__currentLoopData = $availability->slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="d-flex mb-2 slot-row">
                                                    <input type="time"
                                                        name="slots_start[]"
                                                        class="form-control w-50"
                                                        value="<?php echo e($slot->start_time); ?>">

                                                    <input type="time"
                                                        name="slots_end[]"
                                                        class="form-control w-50 ms-2"
                                                        value="<?php echo e($slot->end_time); ?>">

                                                    <button type="button"
                                                        class="btn btn-danger btn-sm ms-2 remove-slot">X</button>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                            <button type="button" class="btn btn-primary btn-sm add-slot">
                                                + Add Slot
                                            </button>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-md-12 mt-3">
                                    <div class="button-group d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary">Update Availability</button>
                                    </div>
                                </div>

                            </form>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener("click", function(e) {

        // Add Slot
        if (e.target.classList.contains("add-slot")) {
            let container = document.querySelector(".slot-container");

            let slotRow = `
            <div class="d-flex mb-2 slot-row">
                <input type="time" name="slots_start[]" class="form-control w-50">
                <input type="time" name="slots_end[]" class="form-control w-50 ms-2">
                <button type="button" class="btn btn-danger btn-sm ms-2 remove-slot">X</button>
            </div>
        `;

            container.insertAdjacentHTML("beforeend", slotRow);
        }

        // Remove Slot
        if (e.target.classList.contains("remove-slot")) {
            e.target.closest(".slot-row").remove();
        }

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\love-linkien\resources\views/admin/availability/edit.blade.php ENDPATH**/ ?>