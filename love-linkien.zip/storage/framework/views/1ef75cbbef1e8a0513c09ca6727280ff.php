

<?php $__env->startSection('content'); ?>
<div class="contents">
    <div class="container-fluid">
        <div class="card card-default card-md mb-4">
            <div class="card-header">
                <h6>Edit Inspiration</h6>
            </div>

            <div class="card-body py-md-30">
                <form method="POST" action="<?php echo e(route('admin.inspirations.update', $inspiration->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        
                        <div class="col-md-6 mb-25">
                            <label class="il-gray fs-14 fw-500 align-center mb-10">Category</label>
                            <select name="category_id" class="form-control select2">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e($inspiration->category_id == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger fs-13"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="col-md-6 mb-25">
                            <label class="il-gray fs-14 fw-500 align-center mb-10">Name</label>
                            <input
                                type="text"
                                name="name"
                                value="<?php echo e(old('name', $inspiration->name)); ?>"
                                class="form-control ih-medium ip-gray radius-xs b-light px-15"
                                required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger fs-13"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="col-md-6 mb-25">
                            <label class="il-gray fs-14 fw-500 align-center mb-10">Slug</label>
                            <input
                                type="text"
                                name="slug"
                                value="<?php echo e(old('slug', $inspiration->slug)); ?>"
                                class="form-control ih-medium ip-gray radius-xs b-light px-15">
                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger fs-13"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="col-md-12 mb-25">
                            <label class="il-gray fs-14 fw-500 align-center mb-10">Short Description</label>
                            <textarea
                                name="short_description"
                                rows="3"
                                class="form-control ih-medium ip-gray radius-xs b-light px-15"><?php echo e(old('short_description', $inspiration->short_description)); ?></textarea>
                            <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger fs-13"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="col-md-12 mb-25">
                            <label class="il-gray fs-14 fw-500 align-center mb-10">Notes</label>
                            <textarea
                                name="notes"
                                rows="3"
                                class="form-control ih-medium ip-gray radius-xs b-light px-15"><?php echo e(old('notes', $inspiration->notes)); ?></textarea>
                            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger fs-13"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="col-md-6 mb-25">
                            <div class="form-group tagSelect-rtl">
                                <label class="il-gray fs-14 fw-500 align-center mb-10">Tags</label>
                                <div class="dm-select">
                                    <select name="tags[]" id="select-tag" class="form-control select2" multiple>
                                        <?php
                                        $selectedTags = json_decode($inspiration->tags ?? '[]');
                                        ?>
                                        <?php $__currentLoopData = $selectedTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tag); ?>" <?php echo e(in_array($tag, $selectedTags) ? 'selected' : ''); ?>>
                                            <?php echo e($tag); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger fs-13"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="col-md-6 mb-25">
                            <label class="il-gray fs-14 fw-500 align-center mb-10">Image</label><br>

                            <input type="file" name="image" class="form-control ih-medium ip-gray radius-xs b-light px-15">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger fs-13"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <?php if($inspiration->image): ?>
                            <img src="<?php echo e(asset($inspiration->image)); ?>" alt="Image" width="100" class="mb-2 rounded">
                            <?php endif; ?>
                        </div>

                        
                        <div class="col-md-12">
                            <div class="button-group d-flex pt-sm-25 justify-content-md-end justify-content-start">
                                <button type="submit" class="btn btn-primary btn-default btn-squared text-capitalize radius-md shadow2 btn-sm">
                                    Update
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            placeholder: "Select or type tags",
            tags: true,
            tokenSeparators: [',']
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\love-linkien\resources\views/admin/inspirations/edit.blade.php ENDPATH**/ ?>