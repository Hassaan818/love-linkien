<footer class="footer-wrapper">
         <div class="footer-wrapper__inside">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-6">
                     <div class="footer-copyright">
                        <p><span>  Copyright © <?php echo e(date("Y")); ?></span><a href="#">. All rights reserved.</a>
                        </p>
                     </div>
                  </div>
                 <!--  <div class="col-md-6">
                     <div class="footer-menu text-end">
                        <ul>
                           <li>
                              <a href="#">About</a>
                           </li>
                           <li>
                              <a href="#">Team</a>
                           </li>
                           <li>
                              <a href="#">Contact</a>
                           </li>
                        </ul>
                     </div>
                     
                  </div> -->
               </div>
            </div>
         </div>
      </footer><?php /**PATH C:\laragon\www\love-linkien\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>