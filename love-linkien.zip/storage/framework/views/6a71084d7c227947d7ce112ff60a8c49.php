

<?php $__env->startSection('content'); ?>
<div class="contents">
    <div class="container-fluid">
        <div class="card card-default card-md mb-4">
            <div class="card-header">
                <h6>Inspiration Details</h6>
            </div>

            <div class="card-body">
                <div class="mb-3"><strong>Name:</strong> <?php echo e($inspiration->name); ?></div>
                <div class="mb-3"><strong>Slug:</strong> <?php echo e($inspiration->slug); ?></div>
                <div class="mb-3"><strong>Category:</strong> <?php echo e($inspiration->category->name ?? 'N/A'); ?></div>
                <div class="mb-3"><strong>Short Description:</strong> <?php echo e($inspiration->short_description); ?></div>
                <div class="mb-3"><strong>Notes:</strong> <?php echo e($inspiration->notes ?? 'N/A'); ?></div>
                <div class="mb-3">
                    <strong>Tags:</strong>
                    <?php if($inspiration->tags): ?>
                        <?php $__currentLoopData = json_decode($inspiration->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="rounded-pill p-1 bg-primary text-white"><?php echo e($tag); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <strong>Image:</strong><br>
                    <?php if($inspiration->image): ?>
                        <img src="<?php echo e(asset($inspiration->image)); ?>" width="200" class="rounded">
                    <?php else: ?>
                        <span class="text-muted">No Image</span>
                    <?php endif; ?>
                </div>

                <a href="<?php echo e(route('admin.inspirations.index')); ?>" class="btn btn-secondary btn-sm mt-3">Back</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\love-linkien\resources\views/admin/inspirations/show.blade.php ENDPATH**/ ?>