<?php if($errors->any()): ?>
<div class="alert-big alert alert-danger  alert-dismissible fade show " role="alert">
    <div class="alert-content">
        <h6 class="alert-heading">Errors</h6>
        <strong>Please fix the following validation errors</strong>
        
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="button" class="btn-close text-capitalize" data-bs-dismiss="alert" aria-label="Close">
        <!-- <img src="<?php echo e(asset('img/svg/x.svg')); ?>" alt="x" class="svg" aria-hidden="true"> -->
        </button>

    </div>
</div>
<?php endif; ?><?php /**PATH C:\laragon\www\love-linkien\resources\views/admin/partials/validation-error-messages.blade.php ENDPATH**/ ?>