<div class="sidebar-wrapper" style="margin-top: 5px;">
    <div class="sidebar sidebar-collapse" id="sidebar">
        <div class="sidebar__menu-group">
            <ul class="sidebar_nav">
                <li class="<?php echo e((request()->is('admin/dashboard')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                        <span class="nav-icon uil uil-create-dashboard"></span>
                        <span class="menu-text">Dashboard</span>
                    </a>
                </li>
                <li class="<?php echo e((request()->is('admin/categories')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.categories.index')); ?>">
                        <span class="nav-icon uil uil-create-dashboard"></span>
                        <span class="menu-text">Categories</span>
                    </a>
                </li>
                <li class="<?php echo e((request()->is('admin/inspirations')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.inspirations.index')); ?>">
                        <span class="nav-icon uil uil-create-dashboard"></span>
                        <span class="menu-text">Inspirations</span>
                    </a>
                </li>

            </ul>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\love-linkien\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>