

<?php $__env->startSection('content'); ?>
<div class="contents">
    <div class="demo2 mb-25 t-thead-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-main">
                        <h4 class="text-capitalize breadcrumb-title">Edit Category</h4>
                    </div>
                </div>

                <div class="col-lg-12">
                    <div class="card card-default card-md mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6>Edit Category</h6>
                            <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-light btn-default btn-squared">
                                Back to List
                            </a>
                        </div>

                        <div class="row">
                            <div class="col-md-8 mb-25 offset-md-2">
                                <?php echo $__env->make('admin.partials.success-messages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <?php echo $__env->make('admin.partials.validation-error-messages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        </div>

                        <div class="card-body py-md-30">
                            <form method="POST" action="<?php echo e(route('admin.categories.update', $category->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="row">
                                    <div class="col-md-6 mb-25">
                                        <label class="il-gray fs-14 fw-500 align-center mb-10">Name</label>
                                        <input type="text" name="name" value="<?php echo e(old('name', $category->name)); ?>" class="form-control ih-medium ip-gray radius-xs b-light px-15" placeholder="Category Name">
                                    </div>

                                    <div class="col-md-6 mb-25">
                                        <label class="il-gray fs-14 fw-500 align-center mb-10">Slug</label>
                                        <input type="text" name="slug" value="<?php echo e(old('slug', $category->slug)); ?>" class="form-control ih-medium ip-gray radius-xs b-light px-15" placeholder="Slug">
                                    </div>

                                    <div class="col-md-12 mb-25">
                                        <label class="il-gray fs-14 fw-500 align-center mb-10">Description</label>
                                        <textarea name="description" class="form-control ih-medium ip-gray radius-xs b-light px-15" placeholder="Description"><?php echo e(old('description', $category->description)); ?></textarea>
                                    </div>

                                    <div class="col-md-6 mb-25">
                                        <label class="il-gray fs-14 fw-500 align-center mb-10">Image</label>
                                        <input type="file" name="image" class="form-control ih-medium ip-gray radius-xs b-light px-15">
                                        <?php if($category->image): ?>
                                            <div class="mt-2">
                                                <img src="<?php echo e(asset('storage/' . $category->image)); ?>" alt="Category Image" width="80">
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="button-group d-flex pt-sm-25 justify-content-md-end justify-content-start">
                                            <button type="submit" class="btn btn-primary btn-default btn-squared text-capitalize radius-md shadow2 btn-sm">
                                                Update
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- ends: card -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\love-linkien\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>