

<?php $__env->startSection('content'); ?>
<div class="contents">
    <div class="container-fluid">
        <div class="card card-default card-md mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6>Meeting Details</h6>
                <a href="<?php echo e(route('admin.meetings.index')); ?>" class="btn btn-sm btn-secondary">Back</a>
            </div>

            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <strong>Meeting With:</strong> <?php echo e($meeting->adminUser->name ?? '—'); ?>

                    </div>

                    <div class="col-md-6 mb-3">
                        <strong>User:</strong> <?php echo e($meeting->user->name ?? '—'); ?>

                    </div>

                    <div class="col-md-6 mb-3">
                        <strong>Meeting Date:</strong> <?php echo e($meeting->meeting_date); ?>

                    </div>

                    <div class="col-md-6 mb-3">
                        <strong>Start Time:</strong> <?php echo e(\Carbon\Carbon::parse($meeting->start_time)->format('h:i A')); ?>

                    </div>

                    <div class="col-md-6 mb-3">
                        <strong>End Time:</strong> <?php echo e(\Carbon\Carbon::parse($meeting->end_time)->format('h:i A')); ?>

                    </div>

                    <div class="col-md-6 mb-3">
                        <strong>Name:</strong> <?php echo e($meeting->name); ?>

                    </div>

                    <div class="col-md-6 mb-3">
                        <strong>Phone:</strong> <?php echo e($meeting->phone); ?>

                    </div>

                    <div class="col-md-6 mb-3">
                        <strong>Email:</strong> <?php echo e($meeting->email); ?>

                    </div>

                    <div class="col-md-12 mb-3">
                        <strong>Description:</strong><br>
                        <?php if($meeting->description): ?>
                        <p class="mt-2"><?php echo e($meeting->description); ?></p>
                        <?php else: ?>
                        <span class="text-muted">No description provided.</span>
                        <?php endif; ?>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\love-linkien\resources\views/admin/meetings/show.blade.php ENDPATH**/ ?>