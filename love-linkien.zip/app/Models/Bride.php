<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Bride extends Model
{
    protected $fillable = ['bride_name', 'groom_name', 'date', 'user_id'];

    
}
