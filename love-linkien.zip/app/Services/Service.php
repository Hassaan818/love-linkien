<?php

namespace App\Services;

class Service {
    protected array $response = [
        'code' => 2000,
        'message' => "success",
        'data' => null,
    ];

}
