<?php

use App\Models\Availability;
use App\Services\Service;

class AvailabilityService extends Service
{
    
}